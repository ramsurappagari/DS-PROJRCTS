use credit_cards;

## Query 1- Group the customers based on their income type and find the average of their annual_income
select Type_Income,AVG(Annual_Income) from credit_cards group by Type_Income;

## Query 2- Find the female owners of Car and Property
select * from credit_card where GENDER='F' and Car_Owner='Y' and Propert_Owner='Y'; 

## Query 3- Find the male customers who are staying with their families?
SELECT * FROM credit_card WHERE GENDER = 'M' AND Family_Members > 1;

## Query 4- list of the top-5 people with highest income
select * from credit_card order by Annual_income desc limit 5;

## Query 5- How many married people are having with bad credit?
select count(Employed_days) as Married_People_BadCredit from credit_card where Marital_status="Married" and Employed_days>0;

## Query 6- What is the highest education level and what is the total count?
select EDUCATION as Highest_Education_Level, count(EDUCATION) as Total_count  from credit_card where EDUCATION="Academic degree"; 

## Query 7- Between Married Male and Females who is having more bad credit?
select GENDER,Marital_status , COUNT(*) as num_bad_credit from credit_card where Marital_status="Married" and Employed_days>0 group by GENDER;