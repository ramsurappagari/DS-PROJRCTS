use corona_cases;
select * from corona_caseReport;
 
## 1- Find the number of corona patients who faced shortness of breath 
select count(*) as num_corona_patients_whomfacedshortness_ofBreath from corona_caseReport where  corona_caseReport.Shortness_of_breath=1;

## 2- Find the number of negative corona patients who have Fever and Sore_throat
SELECT COUNT(*) AS Neg_Patients_with_Fever_and_SoreThroat FROM corona_case WHERE Corona = 0 AND Fever = 1 AND Sore_throat = 1;

## 3- Group data by month and rank num of positive cases?
select DATE_FORMAT(corona_case.Test_date, '%m') AS Month,count(*) as total_cases, sum(Corona=1) as positive_cases, RANK () OVER (ORDER BY SUM(Corona=1)) as positive_cases_rank from corona_case group by Month

## 4- Find the female negative corona patients who faced cough and headache
select * from corona_case where Sex="female" and Corona=0 and Cough_symptoms=1 and Headache=1;

## 5- How many elderly corona patients have faced breathing problems
select count(Age_60_above) as elder_corona_patients from corona_case where Age_60_above="Yes" and Shortness_of_breath=1;

## 6- Which three symptoms were more common among covid positive people
SELECT
sum(Fever) AS Fever_Count,
SUM(Cough_symptoms) AS Cough_Count,
SUM(Sore_Throat) AS Sore_Throat_Count,
SUM(Shortness_of_breath) AS Shortness_of_breath_Count,
SUM(Headache) AS Headache_Count
FROM
corona_case
WHERE
Corona = 1;


## 7- Which three symptoms were less common among covid negative people
SELECT
sum(Fever) AS Fever_Count,
SUM(Cough_symptoms) AS Cough_Count,
SUM(Sore_Throat) AS Sore_Throat_Count,
SUM(Shortness_of_breath) AS Shortness_of_breath_Count,
SUM(Headache) AS Headache_Count
FROM
corona_case
WHERE
Corona = 0;


## 8- What are the most common symptoms among covid positive males whose known contact was abroad
SELECT
sum(Fever) AS Fever_Count,
SUM(Cough_symptoms) AS Cough_Count,
SUM(Sore_Throat) AS Sore_Throat_Count,
SUM(Shortness_of_breath) AS Shortness_of_breath_Count,
SUM(Headache) AS Headache_Count
FROM
corona_case
WHERE
Corona = 1 and Sex="male" and Known_contact="Abroad";